from odoo import models, fields

class ProjectTask(models.Model):
    _inherit = "project.task"

    start_date = fields.Datetime("Start Date", required=True)
    end_date = fields.Datetime("End Date", required=True)
    
    dependency_ids = fields.Many2many(
        "project.task", 
        "task_dependency_rel", 
        "task_id", 
        "dependency_id", 
        string="Task Dependencies"
    )
