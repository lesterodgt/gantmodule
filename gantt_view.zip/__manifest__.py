{
    'name': 'Gantt View Odoo17',
    'version': '1.0',
    'summary': 'Gantt Chart for Project Tasks in Odoo 17 Community',
    'category': 'Project',
    'author': 'Your Name',
    'license': 'LGPL-3',
    'depends': ['project', 'web_timeline'],
    'data': [
        'views/project_gantt.xml',
    ],
    'installable': True,
    'application': False,
    'auto_install': False,
}