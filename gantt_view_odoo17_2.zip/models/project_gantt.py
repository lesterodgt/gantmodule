from odoo import models, fields

class ProjectTask(models.Model):
    _inherit = 'project.task'

    start_date = fields.Datetime(string='Start Date', default=fields.Datetime.now)
    end_date = fields.Datetime(string='End Date', default=fields.Datetime.now)
    progress = fields.Float(string="Progress", default=0.0)
    project_id = fields.Many2one('project.project', string='Project', required=True)
