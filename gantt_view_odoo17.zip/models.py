from odoo import models, fields

class ProjectTask(models.Model):
    _inherit = 'project.task'

    start_date = fields.Datetime(string='Start Date')
    end_date = fields.Datetime(string='End Date')
