{
    'name': 'Gantt View for Odoo 17',
    'summary': 'Adds Gantt view for project tasks in Odoo Community',
    'category': 'Project',
    'version': '17.0.1.0.0',
    'author': 'Your Name',
    'license': 'AGPL-3',
    'depends': ['project', 'web_gantt'],
    'data': [
        'security/ir.model.access.csv',
        'views/project_gantt_view.xml',
    ],
    'installable': True,
    'application': False,
    'auto_install': False,
}